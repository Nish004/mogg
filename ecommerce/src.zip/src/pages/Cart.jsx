import React from 'react';
import CartItems from '../components/cartitems/CartItems';
import '../pages/CSS/cart.css';

const Cart = () => {
  return (
    <div className='cart-page'>
      
      <CartItems />
      
    </div>
  );
};

export default Cart;
