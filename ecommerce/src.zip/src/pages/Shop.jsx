import React from 'react'
import Hero from '../components/Hero/Hero';


const Shop = () => {
  return (
    <div>
      <Hero/>
    </div>
  )
}

export default Shop;
