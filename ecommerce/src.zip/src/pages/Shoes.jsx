import React from 'react'

const Shoes = () => {
  return (
    <div>
      
    </div>
  )
}

export default Shoes
